const Transform = require('stream').Transform
const eventEmitter = require('./eventEmitter')
const utils = require("./utils");
const {writeLog, writeLogCaBom, writeLogDoiGia, writeLogMaBom,writeLogReceivedFromKIT,writeLogSendToKIT} = require("./logThread")
const COMMAND_ID_AUTO = 245;//kit tự gửi về RFID hay bất kì gì muốn xác thực
const COMMAND_NEW_GAS = 250;//kit tự gửi về có ca bơm mới

class Parser extends Transform {
    constructor(options = {}) {
        super(options);
        this.buffer = [];
        this.arrRes = [];
    }

    _transform(chunk, encoding, cb) {
       // console.log("`_transform`", chunk.length, this.buffer.length)
        this.buffer.push(...chunk);
        this.findTrustData();
        if (this.buffer.length > 2000) {
            this.buffer = [];
            writeLog("Size stack lớn, data gửi nhiễu k parse được");
        }
        cb();
    }

    isTrustData(arr) {
        if (arr.length !== arr[1]) {
            return false;
        }
        let total = arr.reduce((sum, i) => sum += i, 0);
        return (total & 0xff) === 0;
    }

    findTrustData() {
        if (this.buffer[0] !== 16) {
            let next = this.buffer.indexOf(16)
            this.buffer.splice(0, next)
        }
        let cnt = this.buffer[1];
        if (!cnt || cnt > this.buffer.length) {

            return //sai log ra
        }
        this.arrRes = this.buffer.splice(0, cnt);
        let isTrustData = this.isTrustData(this.arrRes)
        if (isTrustData || this.buffer[cnt] === 16) {
            if (isTrustData) {
                if (this.arrRes[this.arrRes.length - 2] === COMMAND_NEW_GAS) {
                    eventEmitter.emit("CabomMoi", this.arrRes[2]);
                     //writeLog("CabomMoiEvent", this.arrRes);
                } else
                    this.push(Buffer.from(this.arrRes));
            }
            if (this.buffer.length > 0) {
                return this.findTrustData()
            }
        }
    }

    getBufferSize() {
        return this.buffer.length
    }
}

module.exports = Parser;
