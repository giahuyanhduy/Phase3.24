#!/bin/bash

# Bước 1: Tắt forever đang chạy
forever stopall

# Bước 2: Cài đặt nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.3/install.sh | bash && \

# Bước 3: Nạp lại bashrc để nvm hoạt động
#source ~/.bashrc
# Bước 3: Nạp lại bashrc để nvm hoạt động
. ~/.nvm/nvm.sh  # Ensure nvm is sourced

# Kiểm tra phiên bản Node.js hiện tại
CURRENT_NODE_VERSION=$(node -v 2>/dev/null || echo "v0.0.0")
REQUIRED_NODE_VERSION="v12.22.12"

# So sánh phiên bản Node.js
if [ "$(printf '%s\n' "$REQUIRED_NODE_VERSION" "$CURRENT_NODE_VERSION" | sort -V | head -n1)" != "$REQUIRED_NODE_VERSION" ]; then
    echo "Current Node.js version is less than $REQUIRED_NODE_VERSION. Updating Node.js..."
    nvm install 12.22.12
else
    echo "Current Node.js version is $CURRENT_NODE_VERSION. No need to update Node.js."
fi

# Đảm bảo Node.js phiên bản 12.22.12 đã được cài đặt
nvm use 12.22.12

# Bước 5: Tải bản cài đặt và giải nén vào thư mục /home/giang/Phase_3
wget http://210.245.26.31/updatekit/v3.2.24.tar.gz -O /home/giang/Phase_3/v3.2.24.tar.gz && \
tar -xvf /home/giang/Phase_3/v3.2.24.tar.gz -C /home/giang/Phase_3 && \
rm /home/giang/Phase_3/v3.2.24.tar.gz


# Bước 6: Cài đặt thư viện serialport phiên bản 10.5.0
npm install serialport@10.5.0

# Kiểm tra xem serialport@10.5.0 đã được cài đặt thành công hay chưa
if npm list serialport | grep -q "serialport@10.5.0"; then
    echo "serialport@10.5.0 đã được cài đặt thành công."
else
    echo "serialport@10.5.0 chưa được cài đặt thành công. Thử cài đặt lại."
    npm install serialport@10.5.0
fi

# Chạy thử chương trình
cd /home/giang/Phase_3
node app.js

# Kiểm tra lỗi và hành động phù hợp
if node app.js 2>&1 | grep -q "TypeError: SerialPort is not a constructor"; then
    # Nếu gặp lỗi, chạy lại bước 6
    npm install serialport@10.5.0
else
    # Nếu không gặp lỗi, chạy forever start app.js
    forever start app.js
fi

# Xóa file capnhat3.2.22.sh
rm -- "$0"