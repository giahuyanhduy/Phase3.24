const fs = require("fs");
const moment = require("moment");
if (!fs.existsSync("./logs")) {
  fs.mkdirSync("./logs");
}
if (!fs.existsSync("./logapp")) {
  fs.mkdirSync("./logapp");
}

function writeLogCaBom() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_chotCa.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeDonGiaHienTai(idcot, don_gia) {
  const path = `./dongia/cot${idcot}.txt`;
  //   const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (don_gia)
    fs.writeFile(path, `${don_gia}`, function (err) {
      if (err) return console.error(err);
    });
}

function readDonGiaHienTai(idcot, cb) {
  const path = `./dongia/cot${idcot}.txt`;
  //   const time = moment().format("DD-MM-YYYY HH:mm:ss");
  fs.readFile(path, "utf8", function (err, data) {
    if (err) {
      if (cb) cb(err);
      return;
    }
    try {
      let don_gia = parseInt(data);
      if (cb) cb(null, don_gia);
    } catch (e) {
      if (cb) cb(e);
    }
  });
}

function writeLogPROCESSQUEUEKIT() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_PROCESSQUEUEKIT.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeLogQueue() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_Queue.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}
function writeLogMaBom() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_maBom.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeLogHanmuc() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_Hanmuc.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeLogSendToKIT() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_SendToKIT.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}
function writeLogReceivedFromKIT() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_ReceivedFromKIT.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}
function writeLogDoiGia() {
  if (!arguments.length) return;
  console.log(Object.values(arguments));
  const path = `./logapp/${moment().format("DD-MM-YYYY")}_doiGia.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeLog() {
  const path = `${__dirname}/logs/${moment().format("DD-MM-YYYY")}.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

function writeLogTimeOut() {
  const path = `${__dirname}/logs/${moment().format("DD-MM-YYYY")}_timeout.log`;
  const time = moment().format("DD-MM-YYYY HH:mm:ss");
  if (fs.existsSync(path)) {
    fs.appendFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`,
      function (err) {
        if (err) return console.error(err);
      }
    );
  } else {
    fs.writeFile(
      path,
      `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`,
      { flag: "wx" },
      function (err) {
        if (err) return console.error(err);
      }
    );
  }
}

module.exports = {
  writeLog,
  writeLogDoiGia,
  writeLogMaBom,
  writeLogCaBom,
  writeLogReceivedFromKIT,
  writeLogSendToKIT,
  writeLogQueue,
  writeLogPROCESSQUEUEKIT,
  writeLogHanmuc,
  writeDonGiaHienTai,
  readDonGiaHienTai,
  writeLogTimeOut,
};
