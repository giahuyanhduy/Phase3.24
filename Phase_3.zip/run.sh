#!/bin/sh
#!/bin/bash
SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"
cd $SCRIPTPATH

otpID=$(forever list | grep hoanglongservice | awk '{print $8}')

if [ $otpID!="" ]; then
    forever stop $otpID
fi

forever start app.js hoanglongservice&



